addappid(1388880)
addappid(1388881,0,"4f1093e270a1c6352d8a8ddc1bf9893a6c5e73e352e1dcdbb30631a12372eb69")
setManifestid(1388881,"6249609811833785285")
addappid(1388882,0,"5da97e9149cd6a0ad0b20ce0a974c73d0a50d4c3b9540e954f21e9036821a154")
setManifestid(1388882,"6815447492973339323")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]