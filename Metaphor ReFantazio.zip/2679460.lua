addappid(2679460)
addappid(228989)
setManifestid(228989,"1332597174812030948")
addappid(2679461,0,"0a945c91ddfaaca28d19da03981f783f8eb23a6dcc1121fb8c0936bb17fe0adb")
setManifestid(2679461,"365661344675266579")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]