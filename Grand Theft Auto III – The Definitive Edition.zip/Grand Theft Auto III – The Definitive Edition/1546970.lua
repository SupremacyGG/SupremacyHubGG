-- manifest & lua provided by: https://www.piracybound.com/discord
-- via manilua
addappid(1546970)
addappid(1546971, 1, "d6dfa8078e89488b58be9d37f6b0e04acd6535686db4037c9036f3ef6b552b84")
setManifestid(1546971, "5655906003401315274", 0)